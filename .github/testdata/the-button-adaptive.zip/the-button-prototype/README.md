# THE BUTTON — adaptive prototype

Godot 4.x project. Open `project.godot` and run.

This build uses an adaptive challenge composer: player timing, rhythm, misses, reaction speed and historical performance change what happens next. Challenge behaviors and modifiers combine dynamically and rare events are intentionally undocumented for blind testing.
