#!/usr/bin/env python3
"""Summarize completed raw wall-clock runs without averaging window FPS."""
import argparse
import hashlib
import json
import math
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--output", required=True, type=Path)
parser.add_argument("runs", nargs="+", type=Path)
args = parser.parse_args()
rows = []
for folder in args.runs:
    source = folder / "sustained-mining.json"
    run = json.loads(source.read_text())
    log = (folder / "godot.log").read_text()
    errors = [line for line in log.splitlines() if line.startswith(("ERROR:", "SCRIPT ERROR:"))]
    for fixture in run["fixtures"]:
        windows = fixture["windows"]
        samples = [value for window in windows for value in window["raw"]["frame_ms"]]
        ordered = sorted(samples)
        initial, final = fixture["initial"], fixture["final"]
        def quantile(fraction):
            return ordered[max(0, math.ceil(len(ordered) * fraction) - 1)]
        rows.append({
            "folder": str(folder.resolve()), "raw_summary_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "fixture": fixture["fixture"], "fixture_stage": fixture.get("fixture_stage", "original fixture"),
            "pickaxe_level": initial["pickaxe_level"], "runtime": run["runtime"],
            "package": run["package"], "harness": run["harness"],
            "renderer": run["renderer"], "adapter": run["adapter"], "window_pixels": run["window_pixels"],
            "rendered": run["rendered"], "physical_iphone": run["physical_iphone"],
            "frames": len(samples), "elapsed_seconds": sum(samples) / 1000,
            "average_fps": 1000 * len(samples) / sum(samples),
            "p95_ms": quantile(.95), "p99_ms": quantile(.99), "max_ms": ordered[-1],
            "over_33_ms": sum(value > 33.34 for value in samples),
            "complete_windows": sum(window["complete_10s_window"] for window in windows),
            "every_full_window_active": fixture["every_full_window_active"],
            "actual_play_progress": fixture["actual_play_progress"], "sustained_180s": fixture["sustained_180s"],
            "inactive_complete_windows": [window["window"] for window in windows if window["complete_10s_window"] and not (window["moved_pixels"] > 1 if fixture["fixture"] == "hub" else window["active_mining_observed"])],
            "mined_resources": final["total_mined"] - initial["total_mined"],
            "picked_resources": final["picked"], "broken": final["broken"] - initial["broken"],
            "distance": final["distance"] - initial["distance"], "depth_before": initial["depth"], "depth_after": final["depth"],
            "memory_before": initial["memory"], "memory_after": final["memory"],
            "route_policy": fixture.get("route_policy", "original DFS"),
            "route_plans": len(fixture.get("route_targets", [])),
            "route_planner_total_ms": fixture.get("route_planning_usec", 0) / 1000,
            "route_planner_max_ms": fixture.get("route_planning_max_usec", 0) / 1000,
            "error_lines": errors,
            "windows": [{key: window[key] for key in ("window", "from_seconds", "to_seconds", "average_fps", "p95_ms", "mined_resources", "moved_pixels", "active_mining_observed")} for window in windows],
        })
report = {
    "runs": rows,
    "limits": [
        "This is native software rendering, not browser or physical iPhone certification.",
        "Frame FPS uses total sampled frames / total wall-clock time, not mean window FPS.",
        "Identical seed, loadout and target policy do not guarantee equal progress/state at equal wall-clock times.",
        "The harness retains raw window samples and JSON snapshots; static-memory growth includes this observer data.",
        "TIME_PROCESS is not exclusive script CPU. Dummy audio does not verify sound playback quality.",
        "Active excavation coverage does not establish full progression or all camera states.",
    ],
}
args.output.write_text(json.dumps(report, indent=2) + "\n")
for row in rows:
    print(row["fixture"], row["runtime"]["version"], round(row["average_fps"], 2), round(row["p95_ms"], 1), "active", row["every_full_window_active"], "mined", row["mined_resources"], "moved", round(row["distance"]))
